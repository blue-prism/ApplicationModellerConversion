﻿namespace BPAMConversionToolPlugin
{
    public interface IPlugin
    {
        // Please create an interface for each public function defined in "public class BPAMConversionToolPlugin : IPlugin"
        // Use "object[] arg" to define parameters
        #region "PLEASE DO NOT REMOVE"
        string SetPath(object[] arg);
        #endregion
        string SetObjectName(object[] arg);
        string SetElementName(object[] arg);
    }

    public class BPAMConversionToolPlugin : IPlugin
    {
        #region "PLEASE DO NOT REMOVE"
        // Description: Used by Attribute section as follows
        // Status: PLEASE DO NOT REMOVE as it is required for the conversion rules to function
        //    <Attribute>
        //      <fromAttribute>Path</fromAttribute>
        //      <toAttribute>wXPath</toAttribute>
        //      <Functions>
        //          <Function Name="SetPath"/>
        //      </Functions>
        //    </Attribute>
        // Usage: update element attributes, replace brackets with square brackets
        // Arguments Usage:
        // arg[0]: InUse
        // arg[1]: Attribute Value
        public string SetPath(object[] arg)
        {
            return arg[1].ToString().Replace("(", "[").Replace(")", "]");
        }
        #endregion

        // Description: Used by ObjectName attribute as follows; it overrides the value defined under ObjectNameSuffix;
        // Status: Not called using default conversion rules file
        //    <ConversionRules Name="IE to Chrome/Edge/Firefox Browser Conversion Rules" BPVersion="6.9.x" ObjectNameSuffix=" - Chrome" ObjectNameFunction="SetObjectName">
        // Usage: update object name, replace "- IE" with "- Chrome"
        // Arguments Usage:
        // arg[0]: Object Name
        public string SetObjectName(object[] arg)
        {
            return arg[0].ToString().Replace("- IE", "- Chrome");
        }

        // Description: Available under Element definition
        // Status: Not called using default conversion rules file
        //      <Element>
        //       <Functions>
        //          <Function Name = "SetElementName" />
        //       </Functions>
        //      </Element>
        // Usage: Update element names, for example, from text "- IE" to "- Chrome"
        // Arguments Usage:
        // arg[0]: Element Value
        public string SetElementName(object[] arg)
        {
            return arg[0].ToString().Replace("- IE", "- Chrome");
        }
    }
}
