﻿namespace BPAMConversionToolPlugin
{
    public interface IPlugin
    {
        // Please create an interface for every public function defined in "public class BPAMConversionToolPlugin : IPlugin"
        // Use "object[] arg" for parameters
        #region "PLEASE DO NOT REMOVE OR CHANGE"
        string SetPath(object[] arg);
        #endregion
        string SetObjectName(object[] arg);
        string SetElementName(object[] arg);
        string SetUIAControlType(object[] arg);
    }

    public class BPAMConversionToolPlugin : IPlugin
    {
        #region "PLEASE DO NOT REMOVE OR CHANGE"
        // Description: Used by Attribute section as follows
        // Status: PLEASE DO NOT REMOVE OR CHANGE as it is required for the default conversion rules to function
        //    <Attribute>
        //      <fromAttribute>Path</fromAttribute>
        //      <toAttribute>wXPath</toAttribute>
        //      <Functions>
        //          <Function Name="SetPath"/>
        //      </Functions>
        //    </Attribute>
        // Usage: update element attributes, replace brackets with square brackets
        // Arguments Usage:
        // arg[0]: InUse
        // arg[1]: Attribute Value
        public string SetPath(object[] arg)
        {
            return arg[1].ToString().Replace("(", "[").Replace(")", "]");
        }
        // Description: Used by Attribute section as follows
        // Status: PLEASE DO NOT REMOVE OR CHANGE as it is required for the default conversion rules to function
        //    <Attribute>
        //      <fromAttribute>Role</fromAttribute>
        //      <toAttribute>uControlType</toAttribute>
        //      <Functions>
        //          <Function Name="SetUIAControlType"/>
        //      </Functions>
        //    </Attribute>
        // or
        //    <Attribute>
        //      <fromAttribute>rRole</fromAttribute>
        //      <toAttribute>puControlType</toAttribute>
        //      <Functions>
        //          <Function Name="SetUIAControlType"/>
        //      </Functions>
        //    </Attribute>
        // Usage: update element attributes, map AA Role to UIA Control Type
        // https://docs.microsoft.com/en-us/windows/win32/winauto/uiauto-msaa#:~:text=Microsoft%20Active%20Accessibility%20is%20the,products%20and%20automated%20testing%20tools.
        // Arguments Usage:
        // arg[0]: InUse
        // arg[1]: Attribute Value
        public string SetUIAControlType(object[] arg)
        {
            string role = arg[1].ToString().ToUpper();
            switch (role)
            {
                case "PUSHBUTTON":
                    return "Button";
                case "CHECKBUTTON":
                    return "CheckBox";
                case "COMBOBOX":
                    return "ComboBox";
                case "LIST":
                    return "List";
                case "LISTITEM":
                    return "ListItem";
                case "DOCUMENT":
                    return "Document";
                case "TEXT":
                    return "Edit";
                case "GROUPING":
                    return "Group";
                case "COLUMNHEADER":
                    return "HeaderItem";
                case "LINK":
                    return "Hyperlink";
                case "GRAPHIC":
                    return "Image";
                case "MENUPOPUP":
                    return "Menu";
                case "MENUBAR":
                    return "MenuBar";
                case "MENUITEM":
                    return "MenuItem";
                case "PANE":
                    return "Pane";
                case "PROGRESSBAR":
                    return "ProgressBar";
                case "RADIOBUTTON":
                    return "RadioButton";
                case "SCROLLBAR":
                    return "ScrollBar";
                case "SEPARATOR":
                    return "Separator";
                case "SLIDER":
                    return "Slider";
                case "SPINBUTTON":
                    return "Spinner";
                case "SPLITBUTTON":
                    return "SplitButton";
                case "STATUSBAR":
                    return "StatusBar";
                case "PAGETABLIST":
                    return "Tab";
                case "PAGETAB":
                    return "TabItem";
                case "TABLE":
                    return "Table";
                case "STATICTEXT":
                    return "Text";
                case "INDICATOR":
                    return "Thumb";
                case "TITLEBAR":
                    return "TitleBar";
                case "TOOLBAR":
                    return "ToolBar";
                case "TOOLTIP":
                    return "ToolTip";
                case "OUTLINE":
                    return "Tree";
                case "OUTLINEITEM":
                    return "TreeItem";
                case "WINDOW":
                    return "Window";
                default:
                    return role;
            }
        }
        #endregion

        // Description: Used by ObjectName attribute as follows; it overrides the value defined under ObjectNameSuffix;
        // Status: Not called using default conversion rules file
        //    <ConversionRules Name="IE to Chrome/Edge/Firefox Browser Conversion Rules" BPVersion="6.9.x" ObjectNameSuffix=" - Chrome" ObjectNameFunction="SetObjectName">
        // Usage: update object name, replace "- IE" with "- Chrome"
        // Arguments Usage:
        // arg[0]: Object Name
        public string SetObjectName(object[] arg)
        {
            return arg[0].ToString().Replace("- IE", "- Chrome");
        }

        // Description: Available under Element definition
        // Status: Not called using default conversion rules file
        //      <Element>
        //       <Functions>
        //          <Function Name = "SetElementName" />
        //       </Functions>
        //      </Element>
        // Usage: Update element names, for example, from text "- IE" to "- Chrome"
        // Arguments Usage:
        // arg[0]: Element Value
        public string SetElementName(object[] arg)
        {
            return arg[0].ToString().Replace("- IE", "- Chrome");
        }
    }
}
