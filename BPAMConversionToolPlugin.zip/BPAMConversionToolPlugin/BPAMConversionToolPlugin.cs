﻿using System.Collections.Generic;

namespace BPAMConversionToolPlugin
{
    public interface IPlugin
    {
        // Please create an interface for every public function defined in "public class BPAMConversionToolPlugin : IPlugin"
        // Use "object[] arg" for parameters
        #region "PLEASE DO NOT REMOVE OR CHANGE"
        string SetPath(object[] arg);
        string SetText(object[] arg);
        string SelectItem(object[] arg);
        string SetAttribute(object[] arg);
        string SetChecked(object[] arg);
        string SetRadioChecked(object[] arg);
        string SetIsConnected(object[] arg);
        #endregion

        #region "PLEASE DO NOT REMOVE"
        string SetUIAControlType(object[] arg);
        #endregion

        string SetObjectName(object[] arg);
        string SetElementName(object[] arg);
        string AttachProcessNameChange(object[] arg);
    }

    public class BPAMConversionToolPlugin : IPlugin
    {
        #region "PLEASE DO NOT REMOVE OR CHANGE"
        // Description: Used by Attribute section as follows
        // Status: PLEASE DO NOT REMOVE OR CHANGE as it is required by the default conversion rules to function
        //    <Attribute>
        //      <fromAttribute>Path</fromAttribute>
        //      <toAttribute>wXPath</toAttribute>
        //      <Functions>
        //          <Function Name="SetPath"/>
        //      </Functions>
        //    </Attribute>
        // Usage: update element attributes, replace brackets with square brackets
        // Arguments Usage:
        // arg[0]: InUse
        // arg[1]: Attribute Value
        public string SetPath(object[] arg)
        {
            if (arg[1].ToString() == "")
            {
                return "";
            }
            // Replace brackets with square brackets
            string strPath = arg[1].ToString().Replace("(", "[").Replace(")", "]");
            // iframe conversion
            string strHTML = "/HTML";
            string[] paths = strPath.Split(new string[] { strHTML }, System.StringSplitOptions.None);
            return strHTML + paths[paths.Length - 1];
        }

        // Description: Set conversion rules for Get Current Value (ReadCurrentValue)
        // Status: PLEASE DO NOT REMOVE OR CHANGE as it is required by the default conversion rules to function
        //      <ReadAction>
        //			<fromReadAction>ReadCurrentValue</fromReadAction>
        //			<toReadAction>WebGetText</toReadAction>
        //          <Function>SetText</Function>
        //		</ReadAction>
        // Usage: return new Action Id, modify the dictionary object so it maps to the exact output desired.
        // Arguments Usage:
        // arg[0]: Action Id, return a different value in order to update it
        // arg[1]: Argument Id Value Pairs, create, update and delete key value pairs in the dictionary to arrive at the needed argument sets for the action returned by the function.
        // arg[2]: Element attribute list post conversion, used for reference only. It has no effect if changed.
        // arg[3]: Object AppTypeInfoId post conversion, e.g. BrowserLaunch, used for reference only. It has no effect if changed.
        public string SetText(object[] arg)
        {
            // Element attribute list
            Dictionary<string, string> attList = (Dictionary<string, string>)arg[2];

            // Get Web Element Type
            if (!attList.TryGetValue("wElementType", out string WebElementType))
            {
                // If not found, return WebGetText
                return "WebGetText";
            }
            // if lower than v6.9; wCssSelector only presents in v6.9 and above
            if (!attList.TryGetValue("wCssSelector", out string WebCSSClass))
            {
                // if TextArea, no conversion rule exists
                if (WebElementType.ToUpper() == "TEXTAREA")
                {
                    return arg[0].ToString();
                }
                else // Other than TextArea
                {
                    return "WebGetText";
                }
            }
            else // v6.9 onwards
            {
                // if TextArea, map to "WebGetValue"
                if (WebElementType.ToUpper() == "TEXTAREA")
                {
                    return "WebGetValue";
                }
                else // Other than TextArea
                {
                    return "WebGetText";
                }
            }
        }

        // Description: Set SelectItem Action conversion rules
        // Status: PLEASE DO NOT REMOVE OR CHANGE as it is required by the default conversion rules to function
        // <Action>
        //			<fromAction>HTMLSelectItem</fromAction>
        //			<toAction>WebSelectListItem</toAction>
        //			<Function>SelectItem</Function>
        // </Action>
        // Usage: return new Action Id, modify the dictionary object so it maps to the exact output desired.
        // Arguments Usage:
        // arg[0]: Action Id, return a different value in order to update it
        // arg[1]: Argument Id Value Pairs, create, update and delete key value pairs in the dictionary to arrive at the needed argument sets for the action returned by the function.
        // arg[2]: Element attribute list post conversion, used for reference only. It has no effect if changed.
        // arg[3]: Object AppTypeInfoId post conversion, e.g. BrowserLaunch, used for reference only. It has no effect if changed.
        public string SelectItem(object[] arg)
        {
            Dictionary<string, string> argList = (Dictionary<string, string>)arg[1];
            // since index takes precedence in Chrome/Edge/Firefox rather than text, it is important to reflect
            // such in the conversion rules in case both item text and item position are filled in IE objects
            if (argList["newtext"] != "")
            {
                argList["itemindex"] = "";
                argList["itemtext"] = argList["newtext"];
            }
            else
            {
                argList["itemindex"] = argList["position"];
                argList["itemtext"] = "";
            }
            if (argList.ContainsKey("propname"))
            {
                argList.Remove("propname");
            }
            argList.Remove("newtext");
            argList.Remove("position");

            return "WebSelectListItem";
        }

        // Description: Set conversion rules for Get HTML Attribute (GetHTMLIdentifier)
        // Status: PLEASE DO NOT REMOVE OR CHANGE as it is required by the default conversion rules to function
        // <Action>
        //			<fromAction>GetHTMLIdentifier</fromAction>
        //			<toAction>WebGetAttribute</toAction>
        //			<Function>SelectItem</Function>
        // </Action>
        // Usage: return new Action Id, modify the dictionary object so it maps to the exact output desired.
        // Arguments Usage:
        // arg[0]: Action Id, return a different value in order to update it
        // arg[1]: Argument Id Value Pairs, create, update and delete key value pairs in the dictionary to arrive at the needed argument sets for the action returned by the function.
        // arg[2]: Element attribute list post conversion, used for reference only. It has no effect if changed.
        // arg[3]: Object AppTypeInfoId post conversion, e.g. BrowserLaunch, used for reference only. It has no effect if changed.
        public string SetAttribute(object[] arg)
        {
            Dictionary<string, string> argList = (Dictionary<string, string>)arg[1];

            string idname = argList["idname"];

            // if attribute is set to value, use WebGetText action
            if (idname.ToLower() == @"""value""")
            {
                argList.Remove("idname");
                return "WebGetText";
            } 
            else // otherwise, map attribute to "Set Attribute", and use WebGetAttribute action instead
            {
                argList["propname"] = argList["idname"];
                argList.Remove("idname");
                return "WebGetAttribute";
            }
        }

        // Description: Set conversion rules for Set Checked [SetChecked] for HTML Check Box
        // Status: PLEASE DO NOT REMOVE OR CHANGE as it is required by the default conversion rules to function
        // <Action>
        //			<fromAction>SetChecked</fromAction>
        //			<toAction>WebSetAttribute</toAction>
        //			<Function>SetChecked</Function>
        // </Action>
        // Usage: return new Action Id, modify the dictionary object so it maps to the exact output desired.
        // Arguments Usage:
        // arg[0]: Action Id, return a different value in order to update it
        // arg[1]: Argument Id Value Pairs, create, update and delete key value pairs in the dictionary to arrive at the needed argument sets for the action returned by the function.
        // arg[2]: Element attribute list post conversion, used for reference only. It has no effect if changed.
        // arg[3]: Object AppTypeInfoId post conversion, e.g. BrowserLaunch, used for reference only. It has no effect if changed.
        public string SetChecked(object[] arg)
        {
            Dictionary<string, string> argList = (Dictionary<string, string>)arg[1];

            string idname = argList["newtext"];

            // Only use WebSetAttribute when SetChecked is set to true, or "true", case insensitive
            if (idname.ToLower() == @"true" | idname.ToLower() == @"""true""")
            {
                argList["propname"] = @"""checked""";
                argList["value"] = @"""true""";
                argList.Remove("newtext");
                return "WebSetAttribute";
            }
            else // Do nothing
            {
                return arg[0].ToString();
            }
        }

        // Description: Set conversion rules for Set Checked [SetChecked] for HTML Radio Button
        // Status: PLEASE DO NOT REMOVE OR CHANGE as it is required by the default conversion rules to function
        // <Action>
        //			<fromAction>SetChecked</fromAction>
        //			<toAction>WebCheckRadio</toAction>
        //			<Function>SetCheckedRadio</Function>
        // </Action>
        // Usage: return new Action Id, modify the dictionary object so it maps to the exact output desired.
        // Arguments Usage:
        // arg[0]: Action Id, return a different value in order to update it
        // arg[1]: Argument Id Value Pairs, create, update and delete key value pairs in the dictionary to arrive at the needed argument sets for the action returned by the function.
        // arg[2]: Element attribute list post conversion, used for reference only. It has no effect if changed.
        // arg[3]: Object AppTypeInfoId post conversion, e.g. BrowserLaunch, used for reference only. It has no effect if changed.
        public string SetRadioChecked(object[] arg)
        {
            Dictionary<string, string> argList = (Dictionary<string, string>)arg[1];

            string idname = argList["newtext"];

            // Only use WebSetAttribute when SetChecked is set to true, or "true", case insensitive
            if (idname.ToLower() == @"true" | idname.ToLower() == @"""true""")
            {
                argList.Remove("newtext");
                return "WebCheckRadio";
            }
            else // Do nothing
            {
                return arg[0].ToString();
            }
        }

        // Description: Set conversion rules for 'Is Connected?' (IsConnected or WebIsConnected)
        // Status: PLEASE DO NOT REMOVE OR CHANGE as it is required by the default conversion rules to function
        //  <ReadAction>
        //    <fromReadAction>IsConnected</fromReadAction>
        //    <toReadAction>WebIsConnected</toReadAction>
        //    <Function>SetIsConnected</Function>
        //    <toReadActionArguments>
        //      <Argument>trackingid</Argument>
        //    </toReadActionArguments>
        //  </ReadAction>
        // Usage: return new Action Id, modify the dictionary object so it maps to the exact output desired.
        // Arguments Usage:
        // arg[0]: Action Id, return a different value in order to update it
        // arg[1]: Argument Id Value Pairs, create, update and delete key value pairs in the dictionary to arrive at the needed argument sets for the action returned by the function.
        // arg[2]: Element attribute list post conversion, used for reference only. It has no effect if changed.
        // arg[3]: Object AppTypeInfoId post conversion, e.g. BrowserLaunch, used for reference only. It has no effect if changed.
        public string SetIsConnected(object[] arg)
        {
            if (arg[3].ToString() == "BrowserAttach")
            {
                return "IsConnected";
            } 
            else
            {
                return "WebIsConnected";
            }
        }
        #endregion

        #region "PLEASE DO NOT REMOVE"
        // Description: Used by Attribute section as follows
        // Status: PLEASE DO NOT REMOVE as it is required by the default conversion rules to function
        //    <Attribute>
        //      <fromAttribute>Role</fromAttribute>
        //      <toAttribute>uControlType</toAttribute>
        //      <Functions>
        //          <Function Name="SetUIAControlType"/>
        //      </Functions>
        //    </Attribute>
        // or
        //    <Attribute>
        //      <fromAttribute>rRole</fromAttribute>
        //      <toAttribute>puControlType</toAttribute>
        //      <Functions>
        //          <Function Name="SetUIAControlType"/>
        //      </Functions>
        //    </Attribute>
        // Usage: update element attributes, map AA Role to UIA Control Type
        // https://docs.microsoft.com/en-us/windows/win32/winauto/uiauto-msaa#:~:text=Microsoft%20Active%20Accessibility%20is%20the,products%20and%20automated%20testing%20tools.
        // Arguments Usage:
        // arg[0]: InUse
        // arg[1]: Attribute Value
        public string SetUIAControlType(object[] arg)
        {
            string role = arg[1].ToString().ToUpper();
            switch (role)
            {
                case "PUSHBUTTON":
                    return "Button";
                case "CHECKBUTTON":
                    return "CheckBox";
                case "COMBOBOX":
                    return "ComboBox";
                case "LIST":
                    return "List";
                case "LISTITEM":
                    return "ListItem";
                case "DOCUMENT":
                    return "Document";
                case "TEXT":
                    return "Edit";
                case "GROUPING":
                    return "Group";
                case "COLUMNHEADER":
                    return "HeaderItem";
                case "LINK":
                    return "Hyperlink";
                case "GRAPHIC":
                    return "Image";
                case "MENUPOPUP":
                    return "Menu";
                case "MENUBAR":
                    return "MenuBar";
                case "MENUITEM":
                    return "MenuItem";
                case "PANE":
                    return "Pane";
                case "PROGRESSBAR":
                    return "ProgressBar";
                case "RADIOBUTTON":
                    return "RadioButton";
                case "SCROLLBAR":
                    return "ScrollBar";
                case "SEPARATOR":
                    return "Separator";
                case "SLIDER":
                    return "Slider";
                case "SPINBUTTON":
                    return "Spinner";
                case "SPLITBUTTON":
                    return "SplitButton";
                case "STATUSBAR":
                    return "StatusBar";
                case "PAGETABLIST":
                    return "Tab";
                case "PAGETAB":
                    return "TabItem";
                case "TABLE":
                    return "Table";
                case "STATICTEXT":
                    return "Text";
                case "INDICATOR":
                    return "Thumb";
                case "TITLEBAR":
                    return "TitleBar";
                case "TOOLBAR":
                    return "ToolBar";
                case "TOOLTIP":
                    return "ToolTip";
                case "OUTLINE":
                    return "Tree";
                case "OUTLINEITEM":
                    return "TreeItem";
                case "WINDOW":
                    return "Window";
                default:
                    return role;
            }
        }
        #endregion

        // Description: Used by ObjectName attribute as follows; it overrides the value defined under ObjectNameSuffix;
        // Status: Not called using default conversion rules file
        //    <ConversionRules Name="IE to Chrome/Edge/Firefox Browser Conversion Rules" BPVersion="6.9.x" ObjectNameSuffix=" - Chrome" ObjectNameFunction="SetObjectName">
        // Usage: update object name, replace "- IE" with "- Chrome"
        // Arguments Usage:
        // arg[0]: Object Name
        public string SetObjectName(object[] arg)
        {
            return arg[0].ToString().Replace("- IE", "- Chrome");
        }

        // Description: Available under Element definition
        // Status: Not called using default conversion rules file
        //      <Element>
        //       <Functions>
        //          <Function Name = "SetElementName" />
        //       </Functions>
        //      </Element>
        // Usage: Update element names, for example, from text "- IE" to "- Chrome"
        // Arguments Usage:
        // arg[0]: Element Value
        public string SetElementName(object[] arg)
        {
            return arg[0].ToString().Replace("- IE", "- Chrome");
        }

        // Description: Set conversion rules for AttachApplication
        // Status: Not called using default conversion rules file
        //      <Action>
        //			<fromAction>AttachApplication</fromAction>
        //			<toAction>AttachApplication</toAction>
        //			<Function>AttachProcessNameChange</Function>
        //      </Action>
        // Usage: return new Action Id, modify the dictionary object so it maps to the exact output desired.
        // Arguments Usage:
        // arg[0]: Action Id, return a different value in order to update it
        // arg[1]: Argument Id Value Pairs, create, update and delete key value pairs in the dictionary to arrive at the needed argument sets for the action returned by the function.
        // arg[2]: Element attribute list post conversion, used for reference only. It has no effect if changed.
        // arg[3]: Object AppTypeInfoId post conversion, e.g. BrowserLaunch, used for reference only. It has no effect if changed.
        public string AttachProcessNameChange(object[] arg)
        {
            Dictionary<string, string> argList = (Dictionary<string, string>)arg[1];
            if (argList["ProcessName"].ToLower() == @"""iexplore""")
            {
                argList["ProcessName"] = @"""chrome""";
            }
            return arg[0].ToString();
        }
    }
}
